package stepdefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.List;

public class BaseMethods {
    public WebDriver driver=new ChromeDriver();

    protected List<WebElement> getelements(By locater){
        return driver.findElements(locater);
    }
    protected  WebElement getElement(By locater){
        return driver.findElement(locater);
    }
}
