package stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import pom.Bikespom;

import java.util.List;

public class mountainBikesSteps extends BaseMethods{
    Bikespom bikespom;
    public mountainBikesSteps(){
        bikespom=new Bikespom();
    }
    @Given("User is in {string} website")
    public void userIsInWebsite(String arg0) {

        driver.get("https://demos.telerik.com/aspnet-core/eshop");
    }
    @When("click login btn")
    public void clickLoginBtn() {

        driver.findElement(By.className("k-button-md")).click();
    }
    @And("User clicks  Bikes category")
    public void userClicksMountainBikesCategory() {
        List<WebElement> elements = getelements(bikespom.getBike());
        for (WebElement element: elements){
            if(element.equals("Bikes")) element.click();
        }

    }
    @And("User clicks Mountains Bikes category")
    public void userClicksMountainsBikesCategory() {
        List<WebElement> elements = getelements(bikespom.getMountainBike());
        for(WebElement element: elements){
            if (element.equals("Mountain Bikes")) element.click();
        }
    }
    @And("Clicks Discounted items only")
    public void clicksDiscountedItemsOnly() {
        Select select = new Select(getElement(By.className("k-radio.k-radio-md")));
        select.selectByValue("2");

    }

    @Then("Bikes should be displayed")
    public void bikesShouldBeDisplayed() {

    }


}
