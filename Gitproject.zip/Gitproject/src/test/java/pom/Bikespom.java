package pom;

import lombok.Data;
import org.openqa.selenium.By;
@Data
public class Bikespom {
    private  final By Bike = By.className("category-heading");
    private  final By MountainBike = By.className("category-heading");
}
